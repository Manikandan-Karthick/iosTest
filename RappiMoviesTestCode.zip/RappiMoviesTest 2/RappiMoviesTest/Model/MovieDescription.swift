//
//  MovieDescription.swift
//  RappiMoviesTest
//
//  Created by manikandan  on 05/04/19.
//  Copyright © 2019 manikandan thirunavukarasu. All rights reserved.


// MoviesDescription is a Data model class
// created properties according to API resoonse values

import UIKit

class MoviesDescription: NSObject, NSCoding {
    
    var movieTitle : String = ""
    var popularity : String = ""
    var voteAverage: String = ""

    /* the below mentioned properties need to activate when required in future
    var videoId : String = ""
    var videostatus: String = ""
    var posterPath : String = ""
    var adult : String = ""
    var vote_average : String = ""
    var originalLanguage : String = ""
 */
    
    init(title: String?, popularity: String?, voteAvg: String?) {
        self.movieTitle = title!
        self.popularity = popularity!
        self.voteAverage = voteAvg!
    }
    override init () {
        // uncomment this line if your class has been inherited from any other class
        //super.init()
    }

// For persistant functionality using userdefaults
// to store MoviesDescription model objects into userdefaults we should cnvert MoviesDescription as NSData
// to convert MoviesDescription object to NSData here we used NSCoder and NSDecoder

    init(json: [String: Any])
    {
        self.movieTitle = (json["title"] as? String)!
        self.popularity = (json["popularity"] as? String)!
        self.voteAverage = (json["vote_average"] as? String)!
    }
    
    func encode(with aCoder: NSCoder)
    {
        aCoder.encode(self.movieTitle, forKey: "title")
        aCoder.encode(self.popularity, forKey: "popularity")
        aCoder.encode(self.voteAverage, forKey: "vote_average")

    }
    
    required init?(coder aDecoder: NSCoder)
    {
        self.movieTitle = (aDecoder.decodeObject(forKey: "title") as? String)!
        self.popularity = (aDecoder.decodeObject(forKey: "popularity") as? String)!
        self.voteAverage = (aDecoder.decodeObject(forKey: "vote_average") as? String)!

    }
}
