//
//  ViewController.swift
//  RappiMoviesTest
//
//  Created by manikandan manikandan on 05/04/19.
//  Copyright © 2019 manikandan thirunavukarasu. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON
import SVProgressHUD


class ViewController: UIViewController, UITableViewDataSource,UITableViewDelegate,UISearchResultsUpdating {
   
    // API KEY : 3ef3f6e035a7e1f0ae5c95095e4db6a7
    // API domain : https://developers.themoviedb.org/3/movies
    
    let POPULAR_MOVIES_URL = "https://api.themoviedb.org/3/movie/popular?api_key=3ef3f6e035a7e1f0ae5c95095e4db6a7&language=en-US&page=1"
    let TOP_RATED_MOVIES_URL = "https://api.themoviedb.org/3/movie/top_rated?api_key=3ef3f6e035a7e1f0ae5c95095e4db6a7&language=en-US&page=1"
    let UPCOMING_MOVIES_URL = "https://api.themoviedb.org/3/movie/upcoming?api_key=3ef3f6e035a7e1f0ae5c95095e4db6a7&language=en-US&page=1"
    
    
    @IBOutlet weak var movieListTableView: UITableView!
    @IBOutlet weak var movieCategoryControl: UISegmentedControl!
    
    var moviesList = [MoviesDescription]()
    var filteredTableData = [MoviesDescription]()
    var moviesSearchController = UISearchController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.title = "Rappi Movies List"

        //get movies list from API - by default its Popular movies
        getMoviesListData(url: POPULAR_MOVIES_URL)
        
        // initiate search bar
        moviesSearchController = ({
            let controller = UISearchController(searchResultsController: nil)
            controller.searchResultsUpdater = self
            controller.dimsBackgroundDuringPresentation = false
            controller.searchBar.sizeToFit()
            controller.searchBar.placeholder = "Search movie"
            movieListTableView.tableHeaderView = controller.searchBar
            
            return controller
        })()
        
        // load movie list tableView
        movieListTableView.reloadData()
    }
    
    
    
    //MARK: - Networking API CALLS
    
    func getMoviesListData(url: String) {
        
        SVProgressHUD.show()

        Alamofire.request(url, method: .get).responseJSON {
            response in
            if response.result.isSuccess {
                let movieJSON : JSON = JSON(response.result.value!)
                self.updateMoviesList(json: movieJSON)
            }
            else {
                SVProgressHUD.dismiss()
                let internetAlertController = UIAlertController(title: "Rappi Movies", message:
                    "Please check your Internet connection!", preferredStyle: .alert)
                internetAlertController.addAction(UIAlertAction(title: "Dismiss", style: .default))
                self.present(internetAlertController, animated: true, completion: nil)
                print("Error \(String(describing: response.result.error))")
            }
        }
    }
    //MARK: - JSON Parsing
    
    func updateMoviesList(json : JSON) {
        
        let tempMovieList = json["results"]
        moviesList.removeAll()
        filteredTableData.removeAll()
        
       for movieJson in tempMovieList.arrayValue {
            let movieDataModel = MoviesDescription(title: movieJson["title"].stringValue, popularity: movieJson["popularity"].stringValue, voteAvg: movieJson["vote_average"].stringValue)
          // Currently using "title","popularity","vote_average" values
        // the below MoviesDescription model values commented - need to activate when required

          /*  movieDataModel.videoId = movieJson["id"].stringValue
            movieDataModel.posterPath = movieJson["poster_path"].stringValue
            movieDataModel.originalLanguage = movieJson["original_language"].stringValue
            movieDataModel.videostatus = movieJson["video"].stringValue
            movieDataModel.adult = movieJson["adult"].stringValue
          */
            moviesList.append(movieDataModel)
        }
        
        // preparing offline data here
        //as we are handling small amount of data from API currently storing offline data into userdefaults

        let archivedObject = NSKeyedArchiver.archivedData(withRootObject: moviesList)
        let defaults = UserDefaults.standard
        let selectedMovieCategory = movieCategoryControl.titleForSegment(at: movieCategoryControl.selectedSegmentIndex)
        if selectedMovieCategory == "Popular" {
            defaults.set(archivedObject, forKey: "Popular")
        }
        else if selectedMovieCategory == "Top" {
            defaults.set(archivedObject, forKey: "Top")
        }
        else if selectedMovieCategory == "Upcoming" {
            defaults.set(archivedObject, forKey: "Upcoming")
        }
        defaults.synchronize()
      
        SVProgressHUD.dismiss()
        movieListTableView.reloadData()
    }
    
    //MARK: - Movies List TableView Delegate methods
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        if  (moviesSearchController.isActive) {
            return filteredTableData.count
        } else {
            return moviesList.count
        }
    }
    //the method returning each cell of the list
   
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! MovieCell
      
        if (moviesSearchController.isActive) && filteredTableData.count>0{
            let movie: MoviesDescription
            movie = filteredTableData[indexPath.row]
            cell.movieTitle.text = movie.movieTitle
            cell.popularityLabel.text = "Popularity: " + movie.popularity
            return cell
        }
        else {
            let movie: MoviesDescription
            movie = moviesList[indexPath.row]
            cell.movieTitle.text = movie.movieTitle
            cell.popularityLabel.text = "Popularity: " + movie.popularity
            return cell
        }
    }
    
    // method to run when table view cell is tapped
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    }
    
    
    
    //MARK: - Play list Category Changing methods
    @IBAction func changeMovieCategory(_ sender: Any) {
        switch movieCategoryControl.selectedSegmentIndex
        {
        case 0:
            // get offline data from userdefaults
            if (UserDefaults.standard.object(forKey: "Popular") != nil) {
                let decodedArray = NSKeyedUnarchiver.unarchiveObject(with: (UserDefaults.standard.object(forKey: "Popular") as! NSData) as Data) as! [MoviesDescription]!
                if (decodedArray?.count)!>0 {
                    moviesList.removeAll()
                    moviesList = decodedArray!
                    movieListTableView.reloadData()
                } else {
                    getMoviesListData(url: POPULAR_MOVIES_URL)
                }
                
            } else {
                // get Online data from API
                getMoviesListData(url: POPULAR_MOVIES_URL)
            }
        case 1:
            // get offline data from userdefaults
            if (UserDefaults.standard.object(forKey: "Top") != nil) {
                let decodedArray = NSKeyedUnarchiver.unarchiveObject(with: (UserDefaults.standard.object(forKey: "Top") as! NSData) as Data) as! [MoviesDescription]!
                if (decodedArray?.count)!>0 {
                    moviesList.removeAll()
                    moviesList = decodedArray!
                    movieListTableView.reloadData()
                } else {
                    getMoviesListData(url: TOP_RATED_MOVIES_URL)
                }
                
            } else {
                // get Online data from API
                getMoviesListData(url: TOP_RATED_MOVIES_URL)
            }
            
        case 2:
            // get offline data from userdefaults
            if (UserDefaults.standard.object(forKey: "Upcoming") != nil) {
                let decodedArray = NSKeyedUnarchiver.unarchiveObject(with: (UserDefaults.standard.object(forKey: "Upcoming") as! NSData) as Data) as! [MoviesDescription]!
                if (decodedArray?.count)!>0 {
                    moviesList.removeAll()
                    moviesList = decodedArray!
                    movieListTableView.reloadData()
                } else {
                    getMoviesListData(url: UPCOMING_MOVIES_URL)
                }
                
            } else {
                // get Online data from API
                getMoviesListData(url: UPCOMING_MOVIES_URL)
            }
        default:
            break
        }
        
    }

    //MARK: - Segue

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    
        if segue.identifier == "showMoviePlayer" {
            if let indexPath = movieListTableView.indexPathForSelectedRow {
                let movie: MoviesDescription
                if isFiltering() {
                    movie = filteredTableData[indexPath.row]
                } else {
                    movie = moviesList[indexPath.row]
                }
                let moviePlayerController = segue.destination as! MoviePlayerViewController
                moviePlayerController.movieDetail = movie
                moviePlayerController.navigationItem.leftBarButtonItem = splitViewController?.displayModeButtonItem
                moviePlayerController.navigationItem.leftItemsSupplementBackButton = true
            }
        }
    }
   
    //MARK: - Movies Search bar methods

    func searchBarIsEmpty() -> Bool {
        return moviesSearchController.searchBar.text?.isEmpty ?? true
    }
    func isFiltering() -> Bool {
        let searchBarScopeIsFiltering = moviesSearchController.searchBar.selectedScopeButtonIndex != 0
        return moviesSearchController.isActive && (!searchBarIsEmpty() || searchBarScopeIsFiltering)
    }
    //MARK: -  search bar delgate method
    func updateSearchResults(for searchController: UISearchController) {
        filteredTableData.removeAll(keepingCapacity: false)
        filteredTableData = moviesList.filter ({( movie : MoviesDescription) -> Bool in
            movie.movieTitle.lowercased().contains(searchController.searchBar.text!.lowercased())
        })
        self.movieListTableView.reloadData()
    }
}

