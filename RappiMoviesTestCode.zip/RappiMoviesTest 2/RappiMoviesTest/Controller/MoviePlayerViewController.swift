//
//  MoviePlayerViewController.swift
//  RappiMoviesTest
//
//  Created by manikandan  on 05/04/19.
//  Copyright © 2019 manikandan thirunavukarasu. All rights reserved.

//Rappi Movies API Test
//MoviePlayerViewController.swift
// Currently displaying basic details from data model MoviesDescription.swift
// In future going to implement movie player with poster

import UIKit

class MoviePlayerViewController: UIViewController {
    @IBOutlet weak var backButton: UIButton!
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var voteAverage: UILabel!
    @IBOutlet weak var popularity: UILabel!
    
    
    var movieDetail : MoviesDescription!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = movieDetail.movieTitle

        titleLabel.text = "Title :" + (movieDetail?.movieTitle)!
        voteAverage.text = "Vote Average : " + (movieDetail?.voteAverage)!
        popularity.text = "Popularity :" + (movieDetail?.popularity)!
    }

    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
